const GOOGLE_API_KEY = document.getElementById('GOOGLEKEY').value
const kmlFilePath = "../public/asset/CACHOEIRINHAZONAS.kml";

const map = L.map('map').setView([-29.9178237, -51.067688], 12);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

const inputGroup = document.querySelector('.input-group');
const logTextarea = document.getElementById('logTextarea');
const locationInput = document.getElementById('location');
let geoJsonLayer = null;
let currentMarker = null;
let originalGeoJSON = null;

// Ao iniciar a página, carregamos o KML
fetch(kmlFilePath)
  .then(response => response.text())
  .then(text => {
    const xml = new DOMParser().parseFromString(text, 'application/xml');
    let geojson = toGeoJSON.kml(xml);

    geojson = removeAltitudeDimension(geojson);

    geojson.features = geojson.features.map(feature => {
      if (feature.geometry && (feature.geometry.type === 'Polygon' || feature.geometry.type === 'MultiPolygon')) {
        return turf.rewind(feature, { reverse: false });
      }
      return feature;
    });

    let newFeatures = [];
    for (let f of geojson.features) {
      if (f.geometry && (f.geometry.type === 'Polygon' || f.geometry.type === 'MultiPolygon')) {
        const result = turf.unkinkPolygon(f);
        result.features.forEach(subF => {
          newFeatures.push(subF);
        });
      } else {
        newFeatures.push(f);
      }
    }
    geojson.features = newFeatures;

    originalGeoJSON = geojson;

    if (geoJsonLayer) {
      map.removeLayer(geoJsonLayer);
    }

    geoJsonLayer = L.geoJSON(geojson, {
      style: function (feature) {
        if (feature.properties && (feature.properties.name === '2ª Zona' || feature.properties.name === '1ª Zona')) {
          return { color: feature.properties.name === '2ª Zona' ? '#8f4fb1' : '#c02d0f' };
        }
        return { color: '#3388ff' };
      },
      onEachFeature: function (feature, layer) {
        if (feature.properties && feature.properties.name) {
          layer.bindTooltip(feature.properties.name, {
            permanent: true,
            direction: 'center',
            className: 'zone-label'
          });
        }
      }
    }).addTo(map);

    map.fitBounds(geoJsonLayer.getBounds());
  })
  .catch(err => {
    console.error("Erro ao carregar o KML:", err);
    Swal.fire('Erro', 'Não foi possível carregar o arquivo KML.', 'error');
  });



locationInput.addEventListener('keydown', function (event) {
  if (event.key === 'Enter' || event.keyCode === 13) {
    event.preventDefault();
    locateBtn.click();
  }
});


document.getElementById('locateBtn').addEventListener('click', function () {
  const inputVal = locationInput.value.trim();
  if (!inputVal) return;

  const enderecoCompleto = inputVal + ", Cachoeirinha - Rio Grande do Sul";

  addLog("LOCALIZANDO ENDERECO: " + enderecoCompleto);

  Swal.fire({
    title: 'Localizando endereço...',
    text: 'Por favor, aguarde.',
    icon: 'info',
    showConfirmButton: false,
    allowOutsideClick: false
  });

  const url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' + encodeURIComponent(enderecoCompleto) + '&key=' + GOOGLE_API_KEY;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      Swal.close();
      locationInput.value = '';

      if (data.status === "OK" && data.results.length > 0) {
        const location = data.results[0].geometry.location;
        const lat = location.lat;
        const lng = location.lng;
        addLog("COORDENADAS ENCONTRADAS: " + lat + ", " + lng);

        const foundZone = getZoneForPoint(lng, lat);
        if (foundZone) {
          addLog("ENDERECO PERTENCE A: " + foundZone);
          Swal.fire('Endereço localizado', 'O endereço está na ' + foundZone + '.', 'success');
        } else {
          addLog("ENDERECO PERTENCE A: Nenhuma zona");
          Swal.fire('Endereço localizado', 'O endereço não se encontra em nenhuma zona definida.', 'info');
        }

       // map.setView([lat, lng], 16);

        if (currentMarker) {
          map.removeLayer(currentMarker);
        }
        currentMarker = L.marker([lat, lng]).addTo(map);

      } else {
        Swal.fire('Erro', 'Não foi possível localizar o endereço.', 'error');
      }
    })
    .catch(err => {
      Swal.close();
      Swal.fire('Erro', 'Ocorreu um erro ao processar a requisição.', 'error');
      console.error(err);
    });
});

function addLog(text) {
  logTextarea.value += text + "\n";
  logTextarea.scrollTop = logTextarea.scrollHeight;
}

function getZoneForPoint(lng, lat) {
  if (!originalGeoJSON) return null;

  const point = turf.point([lng, lat]);

  for (let i = 0; i < originalGeoJSON.features.length; i++) {
    const feature = originalGeoJSON.features[i];
    if (feature.geometry.type === 'Polygon' || feature.geometry.type === 'MultiPolygon') {
      const isInside = turf.booleanPointInPolygon(point, feature);
      if (isInside) {
        if (feature.properties && feature.properties.name) {
          return feature.properties.name;
        } else {
          return "Zona Desconhecida";
        }
      }
    }
  }

  return null;
}

function removeAltitudeDimension(geojson) {
  geojson.features.forEach(f => {
    if (f.geometry.type === 'Polygon') {
      f.geometry.coordinates = f.geometry.coordinates.map(ring => ring.map(c => [c[0], c[1]]));
    } else if (f.geometry.type === 'MultiPolygon') {
      f.geometry.coordinates = f.geometry.coordinates.map(polygon =>
        polygon.map(ring => ring.map(c => [c[0], c[1]]))
      );
    }
  });

  return geojson;
}