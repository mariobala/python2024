Instalação de nodejs requerida Versão 18+
https://nodejs.org/dist/v22.12.0/node-v22.12.0-x64.msi

Para instalar as dependências
npm install

Para rodar o sistema
npm start

Para Empacotar
npx electron-packager ./ ZoneChecker --platform=win32 --arch=x64

Api do Google está no arquivo .env

O KML está no publi/assets