// Modules to control application life and create native browser window
const { app, BrowserWindow } = require('electron')
const fs = require('fs');
const path = require('node:path')
const ejse = require('ejs-electron')
require('dotenv').config();


const GkeyMapa = process.env.GOOGLE_API_KEY;
ejse.data('GkeyMapa', GkeyMapa)


function createWindow () {
  const mainWindow = new BrowserWindow({
    width: 1024,
    height: 768,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: true,
      contextIsolation: false
    }
  })

  mainWindow.loadFile(path.join(__dirname, "views/index.ejs"));
  mainWindow.maximize();
  mainWindow.setMenuBarVisibility(false);

  // Open the DevTools.
   //mainWindow.webContents.openDevTools()


}

app.whenReady().then(() => {
  createWindow()

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})